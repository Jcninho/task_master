import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/models/task.dart';
import '../controllers/task_controller.dart';

class HomeView extends ConsumerWidget {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final asyncTasks = ref.watch(taskControllerProvider);
    return Scaffold(
      body: asyncTasks.when(
        data: (List<Task> data) {
          if (data.isEmpty) {
            return const Center(child: Text('Vous n\'avez pas de tâches'));
          }
          return Text('${data.length}');
        },
        error: (Object error, StackTrace stackTrace) {
          return const Center(child: Text('Une erreur est survenue'));
        },
        loading: () => const CircularProgressIndicator(),
      ),
    );
  }
}
